@extends('frontend.my-account')
@section('myAccount')
    <div class="tab-pane fade" id="v-pills-downloads" role="tabpanel" aria-labelledby="v-pills-downloads-tab" tabindex="0">
        <div class="common_content d-flex align-items-center">
            <a href="./pricing.html" class="btn_2">Browse products</a>
            <p>No downloads available yet.</p>
        </div>
    </div>
@endsection
