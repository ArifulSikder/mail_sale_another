<tbody>
    <tr>
        <td>Subtotal</td>
        <td class="text-end">{{ Cart::subtotal() }} $</span></td>
    </tr>
    <tr>
        <td>Total</td>
        <td class="text-end">{{ Cart::subtotal() }}  $</td>
    </tr>
</tbody>