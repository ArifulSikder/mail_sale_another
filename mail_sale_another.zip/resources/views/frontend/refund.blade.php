@extends('frontend.layouts.master')

@section('title', "Refund")

@section('sideSection')
      
      

    <!-- header section end -->

    <!-- refund section start -->
     <section class="refund-and-policy">
        <div class="container">
            <div class="wrapper">
                <p>Returns and Refunds Policy ========================== Thank you for shopping at Pvaeshop. Please read this policy carefully. This is the Return and Refund Policy of SMM Smart Market. Digital products —————- We issue refunds for digital products within 2 days of the original purchase of the product. We recommend contacting us for assistance if you experience any issues receiving or downloading our products. Contact us ———- If you have any questions about our Returns and Refunds Policy, please contact us: * By email: support@pvaeshop.com</p>
            </div>
        </div>
     </section>
    <!-- refund section end -->

    @endsection